from flask import Blueprint

bp = Blueprint('circulars', __name__)
# Import routes later
